---
packageName: Laravel API Documentation Generator
githubUrl: https://github.com/mpociot/laravel-apidoc-generator
---