<?php

namespace Mpociot\ApiDoc\Tools;

class Flags
{
    public static $shouldBeVerbose = false;
}
